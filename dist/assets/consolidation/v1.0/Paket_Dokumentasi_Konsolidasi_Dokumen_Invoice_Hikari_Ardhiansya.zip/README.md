# Konsolidasi Dokumen Invoice

Hikari Ardhiansya. Versi publik 1.0. Disusun 18 November 2026.

## Isi paket

- Word: Proposal, BRD, PRD, FSD dan Requirement Gathering yang dapat diedit.
- PDF: lima dokumen utama, presentasi 11 slide dan studi kasus publik 8 halaman.
- PPTX: presentasi dengan diagram dan lima tabel native yang dapat diedit.
- SVG: enam diagram arsitektur, proses, status, data logis, distribusi dan gerbang rilis.

Dokumen mengikuti struktur proyek sebelumnya yang mengacu pada template dibimbing. Presentasi menggunakan template PPTX dibimbing yang diberikan.

## Alur utama

Berkas invoice, faktur pajak dan pendukung diterima melalui folder sharing Input. Paket yang belum lengkap ditahan pada Temp. Paket lengkap disusun dan dipindahkan ke Done, dikirim kepada customer, serta diunggah ke sistem data website untuk akses pengguna.

Tujuan proyek adalah mempercepat penyiapan berkas dan membantu pengguna mengetahui dokumen yang masih kurang. Pengiriman dan unggah website mempunyai status terpisah dalam rancangan usulan; Done menyatakan paket lengkap dan tersimpan.

## Fakta dan usulan

Alur Input, Temp, Done, workflow UiPath, pengiriman customer dan akses file lengkap di website mengikuti penjelasan Hikari. Kontribusi historis dicatat sebagai developer.

Kunci customer/invoice/revisi, aturan kelengkapan berversi, pemeriksaan ulang Temp, metadata kasus belum lengkap, kontrol pemulihan, pembagian tanggung jawab serta rencana rilis adalah rancangan usulan. Mekanisme sinkronisasi metadata Temp belum dijelaskan pada informasi proyek; file lengkap dan metadata kekurangan dipisahkan dalam usulan integrasi.

Pemrosesan OCR, pemisahan halaman PDF gabungan, kanal pengiriman, format file dan persetujuan kirim memerlukan keputusan lingkup. Mesin database, endpoint API, layanan penyimpanan dan konfigurasi internal tidak direkayasa sebagai fakta implementasi.

Periode, volume, waktu aktual, biaya dan hasil UAT belum dikonfirmasi. Seluruh perhitungan waktu, biaya, batas ukuran dan target kinerja berlabel DATA DUMMY. Simulasi kapasitas 80 jam per bulan bukan hasil terukur atau penghematan kas. Dokumen tidak menyatakan pengurangan jumlah admin untuk proyek ini.

Delapan pertanyaan dan enam asumsi mencatat keputusan yang masih terbuka. Paket berisi 8 kebutuhan bisnis, 16 fungsi, 8 kebutuhan kualitas, 8 user story dan 24 acceptance criteria. Seluruh fungsi dipetakan ke 24 skenario UAT usulan berstatus Belum Dijalankan; hasil aktual dicatat setelah pengujian yang diizinkan.

## Informasi publik

Nama perusahaan, customer, PIC, email, alamat, nomor invoice dan faktur, nilai transaksi, tanda tangan, screenshot dan konfigurasi internal tidak ditampilkan. Identitas contoh memakai kode DEMO yang dibuat khusus. Tidak ada dokumen transaksi atau contoh penggunaan internal dalam paket ini.

## CV wording in English

**Invoice Document Consolidation**

1. Business context and contribution: Designed a workflow to streamline the manual preparation of customer invoice packages, covering invoices, tax invoices and supporting documents, while improving visibility into missing documents.

2. Solution and implementation: Developed a UiPath workflow to group and consolidate files from a shared Input folder. Incomplete packages were retained in Temp, while complete packages were moved to Done for customer delivery and uploaded to a web-based system for access and monitoring.

3. Business value: Streamlined repetitive document preparation, supported visibility into document completeness and helped ensure that complete, consistently organized invoice packages were available for customer delivery.
