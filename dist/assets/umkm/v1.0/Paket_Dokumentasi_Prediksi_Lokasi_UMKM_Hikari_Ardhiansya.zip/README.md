# Prediksi Lokasi UMKM

Hikari Ardhiansya. Versi publik 1.0. Disusun 18 November 2026.

## Isi paket

- 5 dokumen Word: Proposal, BRD, PRD, FSD dan Requirement Gathering.
- 7 PDF: lima dokumen utama, presentasi 11 slide dan studi kasus 8 halaman.
- 1 PowerPoint dengan diagram, teks dan lima tabel native yang dapat diedit.
- 6 diagram SVG: arsitektur, alur studi, validasi, data logis, pengecualian dan gerbang publikasi.

Dokumen mengikuti struktur proyek sebelumnya berdasarkan template dibimbing. Presentasi memakai template PPTX dibimbing yang diberikan. Dokumen ini adalah dokumentasi portofolio, terpisah dari naskah paper asli.

## Konteks dan kontribusi

Saya mengeksplorasi bagaimana pola data dapat membantu penilaian lokasi UMKM dalam proyek akademik untuk lomba paper. Profil proyek mencantumkan pengembangan model transfer learning VGG16, ResNet50, MobileNet, InceptionResNetV2 dan Xception. Dokumentasi ini merinci kebutuhan, arsitektur usulan serta cara mengevaluasi model secara dapat ditelusuri. Bentuk input, definisi target dan hasil eksperimen perlu dikonfirmasi sebelum menyimpulkan kualitas model.

Kontribusi saya berada pada eksplorasi pendekatan prediksi dan pengembangan model transfer learning yang tercantum pada profil proyek. Pembagian pekerjaan anggota tim, proses pelabelan, sumber data dan pengujian rinci belum dikonfirmasi. Dokumentasi merinci hubungan masalah, pilihan metode dan rencana evaluasi untuk mendukung kelanjutan kajian.

Kedua studi akademik dibuat saat kuliah untuk lomba paper dan belum lolos seleksi. Nama lomba, tahun, pembagian tim dan hasil eksperimen rinci belum tersedia. Paket ini tidak menyatakan publikasi ilmiah, penghargaan atau penggunaan komersial.

## Rancangan dan evaluasi

Keluarga model yang tercantum merupakan arsitektur pengolahan citra. Representasi input proyek asli belum terkonfirmasi. Rancangan usulan memulai eksperimen dengan gerbang keputusan: jika input citra berlabel dan hubungannya dengan target terbukti, gunakan jalur transfer learning. Jika data hanya tabular atau koordinat, tinjau baseline dan rancangan fitur yang sesuai terlebih dahulu. Penggabungan fitur bisnis dengan citra, sumber citra satelit dan hasil pemeringkatan lokasi tidak diasumsikan sebagai implementasi historis.

Untuk skenario klasifikasi citra yang disetujui, usulan memakai macro F1, confusion matrix dan dukungan tiap kelas. Baseline kelas mayoritas dihitung dari train. Lima kandidat berbagi manifest split yang sama, dengan preprocessing yang sesuai arsitekturnya. Seleksi memakai validation, kemudian kandidat terpilih dievaluasi pada holdout. Jika target ternyata regresi atau ranking, metrik dan baseline perlu ditetapkan ulang sebelum eksperimen. Tidak ada model pemenang yang dapat dinyatakan dari informasi saat ini.

Manfaat yang dituju adalah menyediakan pendekatan yang lebih terstruktur untuk mempelajari pola terkait penilaian lokasi usaha. Nilai studi terletak pada perumusan masalah, perbandingan metode dan keterlacakan evaluasi. Kelayakan lokasi, peningkatan omzet, akurasi, penghematan waktu dan penggunaan lapangan belum dibuktikan dalam informasi yang tersedia.

Studi akademik mahasiswa untuk lomba paper. Dokumentasi portofolio versi 1.0 membedakan pengalaman yang disampaikan dari rancangan teknis usulan. Dataset, kode, metrik eksperimen, periode rinci dan hasil validasi aktual belum tersedia untuk publik. Angka konfigurasi dan sumber daya berlabel DATA DUMMY. Dokumen ini tidak menyatakan penggunaan di produksi atau manfaat bisnis yang telah terukur.

Kebutuhan pengguna, stakeholder, arsitektur, aturan data, konfigurasi eksperimen, jadwal, anggaran dan UAT adalah rancangan usulan untuk kelanjutan studi. Bukan bukti wawancara pengguna atau hasil implementasi yang telah diuji. Paket memuat 6 kebutuhan bisnis, 12 fungsi, 6 kebutuhan kualitas, 6 user story dan 12 acceptance criteria. Seluruh fungsi dipetakan ke 16 skenario UAT berstatus Belum Dijalankan. Angka metrik aktual tetap Belum Tersedia.

Contoh anggaran Rp1.760.000 berlabel DATA DUMMY. Jadwal relatif empat minggu serta konfigurasi contoh adalah data dummy, bukan riwayat pengerjaan atau biaya aktual. Tidak ada dataset, notebook, model, screenshot internal, kontak pribadi atau identitas pihak lain yang disertakan.

## Referensi metode usulan

- Keras Applications: https://keras.io/api/applications/
  Rujukan keluarga model dan kebutuhan input citra.

- Keras Transfer learning and fine tuning: https://keras.io/guides/transfer_learning/
  Rujukan alur feature extraction dan fine tuning.

- scikit learn GroupKFold: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.GroupKFold.html
  Rujukan pemisahan berdasarkan kelompok, bukan bukti split proyek asli.
