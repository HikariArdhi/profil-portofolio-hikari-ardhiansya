# Prediksi Harga Saham IBM

Hikari Ardhiansya. Versi publik 1.0. Disusun 18 November 2026.

## Isi paket

- 5 dokumen Word: Proposal, BRD, PRD, FSD dan Requirement Gathering.
- 7 PDF: lima dokumen utama, presentasi 11 slide dan studi kasus 8 halaman.
- 1 PowerPoint dengan diagram, teks dan lima tabel native yang dapat diedit.
- 6 diagram SVG: arsitektur, alur studi, validasi, data logis, pengecualian dan gerbang publikasi.

Dokumen mengikuti struktur proyek sebelumnya berdasarkan template dibimbing. Presentasi memakai template PPTX dibimbing yang diberikan. Dokumen ini adalah dokumentasi portofolio, terpisah dari naskah paper asli.

## Konteks dan kontribusi

Saya mengembangkan pendekatan Recurrent Neural Network untuk mempelajari urutan historis harga saham IBM dalam proyek akademik untuk lomba paper. Dokumentasi ini merinci kebutuhan studi, arsitektur usulan, pembagian data menurut waktu serta rencana perbandingan dengan baseline. Hasil eksperimen aktual belum tersedia untuk publik, sehingga model belum dapat dinyatakan lebih akurat dari baseline atau menghasilkan keuntungan investasi.

Kontribusi saya berada pada pengembangan pendekatan pemodelan data berurutan dan model RNN sebagaimana tercantum pada profil proyek. Sumber dataset, layer, hyperparameter, pembagian tim dan metrik asli belum dikonfirmasi. Dokumentasi merinci kebutuhan forecasting dan rencana evaluasi sebagai dasar kelanjutan studi.

Kedua studi akademik dibuat saat kuliah untuk lomba paper dan belum lolos seleksi. Nama lomba, tahun, pembagian tim dan hasil eksperimen rinci belum tersedia. Paket ini tidak menyatakan publikasi ilmiah, penghargaan atau penggunaan komersial.

## Rancangan dan evaluasi

RNN adalah keluarga metode yang tercantum pada profil. Jenis sel, jumlah layer dan library proyek asli belum dirinci. Rancangan usulan menggunakan eksperimen offline dengan target satu langkah ke depan dan baseline harga terakhir. LSTM, GRU, fitur berita, prediksi real time serta integrasi broker tidak diasumsikan sebagai implementasi proyek.

Usulan mengevaluasi satu langkah observasi berikutnya secara rolling. Pada setiap origin, window hanya memakai harga yang sudah tersedia. Model dan scaler tetap berasal dari pelatihan yang disetujui, tanpa fit ulang pada test. Konteks masa lalu dapat mencakup observasi awal test yang sudah diketahui saat origin berikutnya, tetapi target masa depan tidak boleh menjadi fitur. Prediksi dikembalikan ke satuan asli lalu dibandingkan dengan baseline harga terakhir memakai MAE dan RMSE pada indeks target yang sama. Evaluasi multi langkah membutuhkan protokol tersendiri.

Manfaat yang dituju adalah mempelajari pola harga berurutan dan membangun proses forecasting yang dapat diperiksa. Nilai akademik berasal dari pengendalian kebocoran data, perbandingan baseline dan penjelasan kesalahan. Akurasi, kemampuan meramal perubahan pasar, penghematan waktu dan keuntungan investasi belum dibuktikan oleh informasi proyek yang tersedia.

Studi akademik mahasiswa untuk lomba paper. Dokumentasi portofolio versi 1.0 membedakan pengalaman yang disampaikan dari rancangan teknis usulan. Dataset, kode, metrik eksperimen, periode rinci dan hasil validasi aktual belum tersedia untuk publik. Angka konfigurasi dan sumber daya berlabel DATA DUMMY. Dokumen ini tidak menyatakan penggunaan di produksi atau manfaat bisnis yang telah terukur.

Kebutuhan pengguna, stakeholder, arsitektur, aturan data, konfigurasi eksperimen, jadwal, anggaran dan UAT adalah rancangan usulan untuk kelanjutan studi. Bukan bukti wawancara pengguna atau hasil implementasi yang telah diuji. Paket memuat 6 kebutuhan bisnis, 12 fungsi, 6 kebutuhan kualitas, 6 user story dan 12 acceptance criteria. Seluruh fungsi dipetakan ke 16 skenario UAT berstatus Belum Dijalankan. Angka metrik aktual tetap Belum Tersedia.

Contoh anggaran Rp1.430.000 berlabel DATA DUMMY. Jadwal relatif empat minggu serta konfigurasi contoh adalah data dummy, bukan riwayat pengerjaan atau biaya aktual. Tidak ada dataset, notebook, model, screenshot internal, kontak pribadi atau identitas pihak lain yang disertakan.

## Referensi metode usulan

- TensorFlow Time series forecasting: https://www.tensorflow.org/tutorials/structured_data/time_series
  Rujukan window, baseline dan pemodelan urutan waktu.

- scikit learn TimeSeriesSplit: https://scikit-learn.org/stable/modules/generated/sklearn.model_selection.TimeSeriesSplit.html
  Rujukan pembagian data berurutan.

- scikit learn Common pitfalls: https://scikit-learn.org/stable/common_pitfalls.html
  Rujukan pemisahan fit preprocessing dari evaluasi.
