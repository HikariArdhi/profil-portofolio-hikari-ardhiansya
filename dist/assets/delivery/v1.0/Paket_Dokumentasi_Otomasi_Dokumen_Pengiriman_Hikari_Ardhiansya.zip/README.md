# Otomasi Dokumen Pengiriman

Hikari Ardhiansya. Versi publik 1.0. Disusun 17 November 2026.

Paket dokumentasi menggunakan struktur proyek sebelumnya yang mengacu pada template dibimbing.

## Isi

- Word: Proposal, BRD, PRD, FSD dan Requirement Gathering yang dapat diedit.
- PDF: lima dokumen utama, presentasi 11 slide dan studi kasus publik 8 halaman.
- Presentasi: PPTX dengan tabel serta diagram native yang dapat diedit.
- Diagram: enam diagram SVG publik.

## Alur utama

Email diterima, lampiran diunduh, nomor dokumen dicari pada sistem, delivery note dibuat, hasil diunduh dari sistem, kemudian monitoring dokumen diperbarui.

## Status informasi

Perusahaan logistik, PIC, kontak, alamat, logo, QR, sistem internal, data transaksi, screenshot, kode dan informasi komersial asli telah diganti istilah umum atau dihilangkan. Berkas asli tidak dilampirkan.

Peran Hikari adalah developer. Kontrol teknis, pembagian tanggung jawab, rencana 10 minggu, biaya dan skenario pengujian merupakan rekonstruksi usulan. Seluruh angka simulasi berlabel DATA DUMMY. Hasil UAT aktual, periode implementasi dan volume aktual belum dikonfirmasi.

Pemilik proyek menyampaikan perubahan kebutuhan admin dari 6 menjadi 3, setara 50%. Validasi periode, volume pembanding serta atribusi masih diperlukan. Angka simulasi waktu tidak digunakan untuk membuktikan perubahan jumlah admin.

OCR, input item, variasi sistem dan pencetakan hanya aktif jika lingkupnya dikonfirmasi. Delapan pertanyaan terbuka dan enam asumsi tercatat pada Requirement Gathering. FSD memetakan 16 fungsi ke 24 skenario UAT yang belum dijalankan.

## CV wording in English

**Delivery Document Automation**

1. Business context and contribution: Developed a repeatable workflow for delivery document preparation, covering email attachments, document lookup, delivery note creation, file retrieval and monitoring updates.

2. Solution and implementation: Built a UiPath workflow to process incoming delivery instructions, locate the corresponding document in the operational system, generate and download delivery notes, and update the document monitoring records.

3. Business value: Supported a reduction in the administrative staffing requirement from six to three people, as reported by the project owner, while reducing repetitive handling and improving document traceability.
